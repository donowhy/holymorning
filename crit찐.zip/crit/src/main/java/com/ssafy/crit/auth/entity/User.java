package com.ssafy.crit.auth.entity;

import com.ssafy.crit.auth.entity.enumType.AuthProvider;
import com.ssafy.crit.auth.entity.enumType.Grade;
import com.ssafy.crit.auth.entity.enumType.Role;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import javax.persistence.*;
import java.util.Date;

@Entity
@Getter
@NoArgsConstructor
@Table(name = "users")
public class User extends BaseTimeEntity {
    @Id
    @Column(name = "user_id")
    private String id;

    @Column(nullable = false)
    private String nickname;

    @Column(nullable = false)
    private String password;

    @Column(nullable = false)
    private String email;

    @Column
    private String profileImageUrl;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Role role;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private AuthProvider authProvider;

    @Column(length = 300)
    private String refreshToken;

    private Date tokenExpirationTime;

<<<<<<< HEAD
    private String tid;

    @Builder
    public User(String id, String nickname, String password, String email, String profileImageUrl, Role role, AuthProvider authProvider, String refreshToken, Date tokenExpirationTime, String tid){
=======
    private int exp;

    private int point;

    @Enumerated(EnumType.STRING)
    private Grade grade;

    @Column
    private Boolean isChecked;

//    @Builder
//    public User(String id, String nickname, String password, String email, String profileImageUrl, Role role, AuthProvider authProvider, String refreshToken, Date tokenExpirationTime){
//        this.id = id;
//        this.nickname = nickname;
//        this.password = password;
//        this.email = email;
//        this.profileImageUrl = profileImageUrl;
//        this.role = role;
//        this.authProvider = authProvider;
//        this.refreshToken = refreshToken;
//        this.tokenExpirationTime = tokenExpirationTime;
//    }

    @Builder
    public User(String id, String nickname, String password, String email, String profileImageUrl, Role role, AuthProvider authProvider, String refreshToken, Date tokenExpirationTime, int exp, int point, Grade grade, Boolean isChecked) {
>>>>>>> ce44c29 ([fix] user domain depart and fix board code)
        this.id = id;
        this.nickname = nickname;
        this.password = password;
        this.email = email;
        this.profileImageUrl = profileImageUrl;
        this.role = role;
        this.authProvider = authProvider;
        this.refreshToken = refreshToken;
        this.tokenExpirationTime = tokenExpirationTime;
<<<<<<< HEAD
        this.tid = tid;
=======
        this.exp = exp;
        this.point = point;
        this.grade = grade;
        this.isChecked = false;
>>>>>>> ce44c29 ([fix] user domain depart and fix board code)
    }

    /*
    ** 엔티티 관련 비즈니스 로직
     */
    public void passwordEncode(BCryptPasswordEncoder bCryptPasswordEncoder) {
        this.password = bCryptPasswordEncoder.encode(this.password);
    }

    public void updateRefreshToken(String refreshToken, Date refreshTokenExpirationTime) {
        this.refreshToken = refreshToken;
        this.tokenExpirationTime = refreshTokenExpirationTime;
    }

    public void expireRefreshToken(Date now) {
        this.tokenExpirationTime = now;
    }

    public User update(String name, String picture){
        this.nickname = name;
        this.profileImageUrl = picture;
        return this;
    }

    public String getRoleKey(){
        return this.role.getKey();
    }

<<<<<<< HEAD
    public void updateTid(String tid) {
        this.tid = tid;
=======
    public void loginExp(int exp, boolean isChecked){
        this.exp = exp + 10;
        this.isChecked = true;
    }
    public void setGrade(int exp){
        this.grade = Grade.getGradeByExp(exp);
    }

    public void setIsChecked(Boolean isChecked) {
        this.isChecked = isChecked;
>>>>>>> ce44c29 ([fix] user domain depart and fix board code)
    }
}
