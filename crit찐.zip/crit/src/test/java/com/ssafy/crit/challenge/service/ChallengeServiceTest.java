package com.ssafy.crit.challenge.service;

import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest

class ChallengeServiceTest {
    ChallengeService challengeService;

}