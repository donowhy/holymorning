package com.ssafy.crit.challenge.entity;

public enum Cert {
    PHOTO, WEBRTC
}

