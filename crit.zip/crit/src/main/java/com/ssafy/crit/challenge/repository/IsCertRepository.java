package com.ssafy.crit.challenge.repository;

import com.ssafy.crit.challenge.entity.IsCert;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IsCertRepository extends JpaRepository<IsCert,Long> {
}
