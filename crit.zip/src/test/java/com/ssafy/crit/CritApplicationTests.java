package com.ssafy.crit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CritApplicationTests {

	@Test
	void contextLoads() {
	}

}
